import React, { Component } from 'react';
import Authenticate from 'react-openidconnect';
 

const OidcSettings = {
  authority: "https://login.yourdomain.com",
  client_id: "your client id",
  redirect_uri: 'https://localhost:9090',    
  response_type: 'token id_token',
  
  scope: 'openid',
  post_logout_redirect_uri: 'https://localhost:9090'
};

const Authenticated = (user) => { 
  if (user !== undefined && user.user !== undefined) {
   return (<div>Hello dear {user.user.profile.display_name} you are authenticated with mail {user.user.profile.email}.</div>);
  }
  return null;
};

class App extends Component {
 
  constructor(props) {
    super(props);
    this.userLoaded = this.userLoaded.bind(this); 
    this.userUnLoaded = this.userUnLoaded.bind(this);

    this.state = { user: undefined };
  }  

  userLoaded(user) {
    if (user)
      this.setState({ "user": user });
  } 
  
  userUnLoaded() {
    this.setState({ "user": undefined });
  } 

  NotAuthenticated() {
    return <div onClick={this.checkMethod}>You are not authenticated please click here to authenticate.</div>; 
  }

  checkMethod(){
    console.log("test"); 
  }

  render() {
    return (          
        <Authenticate OidcSettings={OidcSettings} userLoaded={this.userLoaded} userunLoaded={this.userUnLoaded} renderNotAuthenticated={this.NotAuthenticated}>
          <Authenticated user={this.state.user} />
        </Authenticate>         
    );
  }
}

export default App;